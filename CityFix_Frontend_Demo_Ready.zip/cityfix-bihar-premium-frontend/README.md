# CityFix Bihar — Premium Frontend

This version uses the supplied CityFix image as the **full-page background**, with a dark glass overlay so all website content sits cleanly on top.

The Cloud Mesh artwork is used as:
- a medium-sized technology-partner poster at the top-right
- a small logo tile on the fixed left rail

## Features
- Live HH:MM:SS clock
- English / Hindi UI toggle
- Civic issue categories
- Complaint form with photo upload UI
- Complaint ID demo + tracking timeline
- Citizen feedback and star rating
- Floating CityFix AI assistant
- AI assistant quick prompts
- Browser speech-to-text microphone support where supported
- Responsive desktop/tablet/mobile layout
- Backend-ready JavaScript handlers

## Backend integration
Replace the demo handlers in `app.js` with your APIs:
- POST complaint
- GET complaint by ID
- POST feedback
- image upload
- AI chat endpoint
- authentication/user profile if needed

The AI panel currently contains a deterministic demo helper so the frontend works without a backend. Connect `reply()` to your AI API later.
