const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

function updateClock(){
  const now = new Date();
  $("#clock").textContent = now.toLocaleTimeString("en-IN",{hour12:false,hour:"2-digit",minute:"2-digit",second:"2-digit"});
}
updateClock(); setInterval(updateClock,1000);

function toast(msg){
  const el=$("#toast"); el.textContent=msg; el.classList.add("show");
  clearTimeout(window.__toast); window.__toast=setTimeout(()=>el.classList.remove("show"),2600);
}

$$(".service").forEach(btn=>{
  btn.addEventListener("click",()=>{
    $("#category").value=btn.dataset.category;
    $("#report").scrollIntoView({behavior:"smooth"});
    setTimeout(()=>$("#title").focus(),500);
  });
});

$("#uploadBtn").addEventListener("click",()=>$("#photo").click());
$("#photo").addEventListener("change",()=>{
  const f=$("#photo").files[0];
  $("#fileName").textContent=f?f.name:"Optional • JPG / PNG";
});

const STORAGE_KEY = "cityfix_complaints_v1";
const FEEDBACK_KEY = "cityfix_feedback_v1";
const getComplaints = () => JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
const saveComplaints = (items) => localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
const makeId = () => `CF-${new Date().getFullYear()}-${Math.floor(10000+Math.random()*90000)}`;

function statusSteps(status){
  const order={"Submitted":0,"Under Review":1,"Action In Progress":2,"Resolved":3,"Rejected":3};
  return order[status] ?? 0;
}
function renderTracking(c){
  const rows=$$(".timeline-row");
  const current=statusSteps(c.status);
  const names=["Submitted","Under Review","Action In Progress","Resolved"];
  rows.forEach((row,i)=>{
    row.classList.remove("done","active");
    const label=row.querySelector("b");
    if(label) label.textContent=names[i];
    const icon=row.querySelector("span");
    if(i<current){ row.classList.add("done"); if(icon) icon.textContent="✓"; }
    else if(i===current){ row.classList.add("active"); if(icon) icon.textContent="•"; }
    else { if(icon) icon.textContent="○"; }
  });
  const details=document.querySelector("#trackResult");
  if(details) details.remove();
  const box=document.createElement("div"); box.id="trackResult"; box.className="success";
  box.style.display="block";
  box.innerHTML=`<strong>${c.complaintId}</strong> — ${c.status}<br><small>${c.title} • ${c.location}</small>`;
  $(".track-card").appendChild(box);
}

$("#complaintForm").addEventListener("submit",(e)=>{
  e.preventDefault();
  const id=makeId();
  const complaint={
    complaintId:id, category:$("#category").value, priority:$("#priority").value,
    title:$("#title").value.trim(), description:$("#description").value.trim(),
    location:$("#location").value.trim(), landmark:$("#landmark").value.trim(),
    status:"Submitted", createdAt:new Date().toISOString()
  };
  const complaints=getComplaints(); complaints.unshift(complaint); saveComplaints(complaints);
  $("#success").style.display="block";
  $("#success").innerHTML=`✓ Complaint saved on this device. Your Complaint ID is <strong>${id}</strong>. Use Track Complaint to check it.`;
  $("#trackId").value=id;
  renderTracking(complaint);
  toast("Complaint submitted and saved");
});

$("#trackBtn").addEventListener("click",()=>{
  const id=$("#trackId").value.trim().toUpperCase();
  if(!id) return toast("Please enter your complaint ID.");
  const c=getComplaints().find(x=>x.complaintId===id);
  if(!c) return toast("Complaint ID not found on this device.");
  renderTracking(c);
  toast(`Status: ${c.status}`);
});

let rating=0;
$$(".rating button").forEach(btn=>btn.addEventListener("click",()=>{
  rating=+btn.dataset.rating;
  $$(".rating button").forEach(x=>x.classList.toggle("selected",+x.dataset.rating<=rating));
}));

$("#feedbackBtn").addEventListener("click",()=>{
  if(!rating && !$("#feedbackText").value.trim()) return toast("Please add a rating or feedback.");
  const feedbacks=JSON.parse(localStorage.getItem(FEEDBACK_KEY)||"[]");
  feedbacks.push({rating,text:$("#feedbackText").value.trim(),createdAt:new Date().toISOString()});
  localStorage.setItem(FEEDBACK_KEY,JSON.stringify(feedbacks));
  $("#feedbackStatus").textContent="✓ Feedback saved on this device.";
  toast("Thank you for your feedback.");
});

/* Hindi/English UI toggle */
let hindi=false;
const translations={
  home:["Home","होम"],services:["Services","सेवाएँ"],report:["Report Issue","समस्या दर्ज करें"],track:["Track","ट्रैक करें"],feedback:["Feedback","प्रतिक्रिया"],
  eyebrow:["BIHAR • CITIZEN SERVICE PORTAL","बिहार • नागरिक सेवा पोर्टल"],
  heroTitle:["Your City.<br><em>Your Voice.</em><br>Your Fix.","आपका शहर।<br><em>आपकी आवाज़।</em><br>आपका समाधान।"],
  heroText:["Report civic problems, get guided help, track complaints and make your neighbourhood better — all from one simple portal.","नागरिक समस्याएँ दर्ज करें, सहायता पाएँ, शिकायत ट्रैक करें और अपने क्षेत्र को बेहतर बनाने में योगदान दें — एक ही पोर्टल से।"],
  reportProblem:["Report a Problem","समस्या दर्ज करें"],trackComplaint:["Track Complaint","शिकायत ट्रैक करें"],
  servicesKicker:["CIVIC SERVICES","नागरिक सेवाएँ"],servicesTitle:["What problem are you facing?","आपको किस समस्या का सामना करना पड़ रहा है?"],servicesSub:["Choose a category and we will guide you.","श्रेणी चुनें, हम आपको आगे का तरीका बताएँगे।"]
};
function setLanguage(){
  Object.entries(translations).forEach(([id,v])=>{
    const nodes=document.querySelectorAll(`[data-i18n="${id}"]`);
    nodes.forEach(n=>n.innerHTML=hindi?v[1]:v[0]);
  });
  $("#langBtn").textContent=hindi?"English":"हिंदी";
  document.documentElement.lang=hindi?"hi":"en";
}
$("#langBtn").addEventListener("click",()=>{hindi=!hindi;setLanguage();});
setLanguage();

/* CityFix AI assistant — detailed bilingual guidance + voice input/output */
const panel=$("#aiPanel"), chat=$("#chat");
let aiHindi=false;
let voiceReplies=true;

function addBubble(text,who="bot",speak=false){
  const div=document.createElement("div");
  div.className=`bubble ${who}`;
  div.textContent=text;
  chat.appendChild(div);
  chat.scrollTop=chat.scrollHeight;
  if(speak && voiceReplies) speakText(text);
}

function speakText(text){
  if(!("speechSynthesis" in window)) { toast("Voice reply is not supported in this browser."); return; }
  window.speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text);
  u.lang=aiHindi?"hi-IN":"en-IN";
  u.rate=.94; u.pitch=1;
  window.speechSynthesis.speak(u);
}

function reply(q){
  const x=q.toLowerCase();

  if(aiHindi){
    if(x.includes("water")||x.includes("पानी")||x.includes("जल")){
      return "पानी की समस्या दर्ज करने के लिए पहले Water Problem चुनें। फिर शिकायत का शीर्षक लिखें, समस्या का पूरा विवरण दें, अपना शहर या जिला और नज़दीकी landmark लिखें। अगर संभव हो तो पानी के leakage या pipe की फोटो भी लगाएँ। अंत में confirmation checkbox चुनकर Submit Complaint दबाएँ। शिकायत बनने के बाद आपको एक Complaint ID मिलेगी, जिसे Track Complaint में डालकर status देखा जा सकता है।";
    }
    if(x.includes("pothole")||x.includes("road")||x.includes("सड़क")||x.includes("गड्ढा")){
      return "सड़क या pothole की शिकायत के लिए Road & Pothole चुनें। Exact location और nearby landmark लिखना बहुत उपयोगी है। गड्ढे की साफ फोटो जोड़ें और Priority तभी High या Urgent रखें जब समस्या से तत्काल safety risk हो। Submit करने के बाद मिलने वाली Complaint ID संभालकर रखें।";
    }
    if(x.includes("streetlight")||x.includes("light")||x.includes("स्ट्रीट")||x.includes("लाइट")){
      return "Streetlight समस्या के लिए Streetlight category चुनें। बताएं कि light पूरी तरह बंद है, flicker कर रही है या pole damaged है। रात में safety issue हो तो description में यह जरूर लिखें और location तथा landmark दें। फोटो उपलब्ध हो तो attach करें।";
    }
    if(x.includes("traffic")||x.includes("signal")||x.includes("ट्रैफिक")||x.includes("सिग्नल")){
      return "Traffic या signal issue के लिए Traffic & Signals चुनें। Signal किस junction पर खराब है, कौन सा signal काम नहीं कर रहा और traffic पर क्या असर पड़ रहा है, यह लिखें। यदि सुरक्षित हो तो location और photo दें।";
    }
    if(x.includes("bus")||x.includes("transport")||x.includes("बस")||x.includes("परिवहन")){
      return "Public Transport category में bus या mobility problem दर्ज कर सकते हैं। Route number, stop या location, समस्या का प्रकार और समय लिखें। इससे complaint को सही context मिलता है।";
    }
    if(x.includes("garbage")||x.includes("clean")||x.includes("कचरा")||x.includes("सफाई")){
      return "Cleanliness category चुनें। Garbage collection, overflowing waste, sanitation या public-area cleanliness की समस्या का स्थान और विवरण लिखें। Photo जोड़ने पर समस्या को verify करना आसान होता है।";
    }
    if(x.includes("track")||x.includes("ट्रैक")||x.includes("status")||x.includes("स्टेटस")){
      return "Complaint track करने के लिए Track section खोलें और अपनी Complaint ID डालें। Demo frontend में Submitted, Under Review, Action in Progress और Resolved stages दिखाई जाती हैं। Real project में यही section आपके backend से live status लेगा।";
    }
    if(x.includes("feedback")||x.includes("प्रतिक्रिया")||x.includes("suggestion")||x.includes("सुझाव")){
      return "Feedback section में 1 से 5 stars चुनें और अपना experience या suggestion लिखें। आप portal की usability, complaint process, response या किसी नए feature के बारे में भी सुझाव दे सकते हैं।";
    }
    return "मैं CityFix Bihar पर आपकी पूरी मदद कर सकता हूँ। आप पानी, सड़क/pothole, streetlight, cleanliness, traffic signal, bus/public transport, complaint tracking या feedback के बारे में पूछ सकते हैं। आप अपना सवाल हिंदी में लिख या बोल सकते हैं।";
  }

  if(x.includes("water")){
    return "For a water problem, open Water Problem. Enter a clear complaint title, describe the leakage or supply issue, add your city/district and a nearby landmark. Attach a photo if available. Submit the complaint and save the Complaint ID. You can then use Track Complaint to follow its progress.";
  }
  if(x.includes("pothole")||x.includes("road")){
    return "For a road or pothole issue, choose Road & Pothole. Give the exact location, nearby landmark and a clear description of the damage. Add a photo when possible. Use High or Urgent priority only when there is an immediate safety concern. Save the Complaint ID after submission.";
  }
  if(x.includes("streetlight")||x.includes("light")){
    return "For a streetlight issue, choose Streetlight. Tell us whether the light is completely off, flickering, damaged, or creating a safety problem. Add the location, landmark and a photo if possible, then submit the complaint.";
  }
  if(x.includes("traffic")||x.includes("signal")){
    return "For a traffic or signal issue, choose Traffic & Signals. Mention the junction, which signal or sign is affected, when you noticed it, and how it is affecting traffic or safety. Add a location and photo when safe.";
  }
  if(x.includes("bus")||x.includes("transport")){
    return "For a bus or public-transport problem, choose Public Transport. Add the route or stop, location, approximate time, and describe the problem. This gives the responsible team useful context.";
  }
  if(x.includes("garbage")||x.includes("clean")||x.includes("sanitation")){
    return "For garbage or sanitation issues, choose Cleanliness. Describe the waste problem, exact location and nearby landmark. A photo can help verification. Submit it and keep the generated Complaint ID.";
  }
  if(x.includes("track")||x.includes("status")){
    return "Open Track Complaint and enter your Complaint ID. The frontend shows four stages: Submitted, Under Review, Action in Progress and Resolved. In the final backend version, these stages can be connected to live department updates.";
  }
  if(x.includes("feedback")||x.includes("suggestion")){
    return "Open Feedback, choose a star rating and write what worked or what should improve. You can comment on the complaint process, portal experience, response quality or suggest a new civic service.";
  }
  return "I can guide you through Water, Road & Pothole, Streetlight, Cleanliness, Traffic & Signals, Public Transport, complaint tracking and feedback. You can ask me a detailed question in English or Hindi, type it, or use the microphone button.";
}

function sendMessage(){
  const input=$("#chatInput");
  const q=input.value.trim();
  if(!q)return;
  addBubble(q,"user");
  input.value="";
  setTimeout(()=>addBubble(reply(q),"bot",true),280);
}

$("#aiFab").addEventListener("click",()=>{
  panel.classList.add("open"); panel.setAttribute("aria-hidden","false");
});
$("#aiClose").addEventListener("click",()=>{
  panel.classList.remove("open"); panel.setAttribute("aria-hidden","true");
});
$("#sendBtn").addEventListener("click",sendMessage);
$("#chatInput").addEventListener("keydown",e=>{if(e.key==="Enter")sendMessage();});

$$(".quick button").forEach(b=>b.addEventListener("click",()=>{
  $("#chatInput").value=aiHindi ? (
    b.dataset.q.includes("water")?"मुझे पानी की समस्या है":
    b.dataset.q.includes("pothole")?"सड़क में गड्ढा है":
    "मैं अपनी शिकायत कैसे ट्रैक करूं?"
  ) : b.dataset.q;
  sendMessage();
}));

$("#aiLang").addEventListener("click",()=>{
  aiHindi=!aiHindi;
  $("#aiLang").textContent=aiHindi?"हिंदी / English":"English / हिंदी";
  addBubble(aiHindi?"ठीक है। अब मैं आपको हिंदी में विस्तार से मार्गदर्शन करूँगा। आप हिंदी में लिख या बोल सकते हैं।":"Okay. I will now guide you in English. You can type or speak your question.", "bot", true);
});

/* Voice reply on/off */
$("#speakToggle").addEventListener("click",()=>{
  voiceReplies=!voiceReplies;
  $("#speakToggle").classList.toggle("off",!voiceReplies);
  $("#speakToggle").textContent=voiceReplies?"🔊 Voice":"🔇 Voice";
  if(!voiceReplies && "speechSynthesis" in window) speechSynthesis.cancel();
});

/* Voice input */
let recognition=null;
if("SpeechRecognition" in window || "webkitSpeechRecognition" in window){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  recognition=new SR();
  recognition.continuous=false;
  recognition.interimResults=false;
  $("#micBtn").addEventListener("click",()=>{
    recognition.lang=aiHindi?"hi-IN":"en-IN";
    recognition.start();
    toast(aiHindi?"बोलिए, मैं सुन रहा हूँ...":"Speak now, I am listening...");
  });
  recognition.onresult=e=>{
    $("#chatInput").value=e.results[0][0].transcript;
    sendMessage();
  };
  recognition.onerror=()=>toast(aiHindi?"माइक्रोफोन की permission या voice input उपलब्ध नहीं है।":"Microphone permission or speech recognition is unavailable.");
}else{
  $("#micBtn").addEventListener("click",()=>{
    toast(aiHindi?"इस browser में voice input supported नहीं है।":"Voice input is not supported in this browser.");
  });
}
